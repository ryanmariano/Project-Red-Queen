package br.com.RedQueenStreet.modelo;

public class Cliente {
    //atributos
    private String Nome;

    private Double Preco;

    private String Categoria;

    private String Marca;

    private String Fornecedor;

    }

}

package br.com.RedQueenStreet.modelo;

public class CarrinhoDeCompras {

    //atributos
    private String Produtos;

    private Double ValorDaCompra;

}
